var canvas;
var ctx;
var imgAuto= new Image();
var imgDisparo =new Image();
var imgDelEnemigo =new Image();
var imgDelEnemigoDos =new Image();


var intervalo;
var vidas=3;
var dolares=0;
var posicionFondo1=0;
var colorBoton="#000"
var inicio=false;


//Audios
var musica = new Audio("audios/cancion.mp3"); //no va
musica.loop = true;

var dineroAudio = new Audio("audios/dinero.mp3");
dineroAudio.loop = false;

var perderDineroAudio = new Audio("audios/perderDinero.mp3");
perderDineroAudio.loop = false;

var winAudio = new Audio("audios/ganaste.mp3");
winAudio.loop = false;

var dieAudio = new Audio("audios/perdiste.mp3");
dieAudio.loop = false;

var autoUno=new Auto(300,450);
var enemigoUno = new Enemigo(100,50);
var enemigoDos = new Enemigo (500-200);
var disparos=[];

var altoEnemigo=40;
var anchoEnemigo=40;
var anchoAuto=150;
var altoAuto=150;
var posXAuto=300;
var posYAuto=450;

var fuente = new FontFace('Rambutan', "url(fonts/Rambutan.otf) format('truetype')");
document.fonts.add(fuente);
fuente.load().then(dibujar);


function dibujar(){
	canvas=document.getElementById("canvas");
	canvas.style.backgroundImage="url(img/fondo2.png)";
	canvas.style.backgroundSize="cover";
	ctx=canvas.getContext('2d');
	// dibujarTextoInicio();

	imgAuto.src="img/personaje.png";
	imgAuto.onload=function(){
		autoUno.dibujar(imgAuto);
	}
	imgDelEnemigo.src="img/enemigo2.png";
	imgDelEnemigo.onload=function(){
		enemigoUno.dibujar(imgDelEnemigo);
	}
	imgDelEnemigoDos.src="img/enemigo2.png";  
	imgDelEnemigoDos.onload=function(){
		enemigoDos.dibujar(imgDelEnemigoDos);
	}
	imgDisparo.src="img/dinero2.png";
	imgDisparo.onload=function(){
		ctx.drawImage(imgDisparo,0,0);
	}

	function iniciar_juego() {
	//	musica.play(); //va?
		borrar();
		dibujarTextos();
		enemigoUno.caer();
		enemigoDos.caer();
		autoUno.dibujar(imgAuto);
		enemigoUno.dibujar(imgDelEnemigo);
		enemigoDos.dibujar(imgDelEnemigoDos);
		moverDisparos();
		dibujarDisparos();
		enemigoUno.colision();
		enemigoDos.colision();

	}
	
	function perdiste() {
		//musica.pause();
		perderDineroAudio.pause();
		dieAudio.play();
		ctx.clearRect(0,0,canvas.width,canvas.height);
		ctx.font="100px Rambutan";
		ctx.fillText("¡Perdiste!",155,300);
		ctx.fillStyle= colorBoton;
		ctx.font= "40px Rambutan";
		ctx.fillText("Intentalo otra vez", 215,350); //Pantalla final//

	}

	function ganaste() {
		musica.pause();
		winAudio.play();
		ctx.clearRect(0,0,canvas.width,canvas.height);
		ctx.font="100px Rambutan";
		ctx.fillText("¡Felicidades!",100,300); 
		ctx.fillStyle= colorBoton;
		ctx.font= "40px Rambutan";
		ctx.fillText("te escapaste de todos", 190,350); //Pantalla final//

	}

	intervalo=setInterval(function(){
		iniciar_juego()
		if(dolares >= 200) {
			ganaste()
		} else if(vidas<=0 || dolares<=-10) {
			perdiste()
		}
	},1000/120);
}

function juego(){
	inicio=true;
	canvas.style.cursor="";

}

function dibujarTextos(){
	ctx.font="20px Rambutan";
	ctx.fillStyle="#000";
	ctx.fillText('Dolares $: '+dolares, 30,50);
	ctx.fillText('Vidas: '+vidas, 700,50);
}
// function dibujarTextoInicio(){
// 	borrar();
// 	ctx.font="40px Arial";
// 	ctx.fillStyle=colorBoton;
// 	ctx.fillText('INICIAR', 290,400);
// }
function Enemigo(x,y){
	this.x=x;
	this.y=y;

	this.dibujar=function(img){
		ctx.drawImage(img,this.x,this.y);
	}
	this.caer=function(){
		if (this.y<600){
			this.y+=1;
		}else{
			this.sortear();
		}
	}
	this.colision=function(){
		if(((this.y+altoEnemigo)>autoUno.y && (this.y)<(autoUno.y+altoAuto)&&(this.x+anchoEnemigo)>autoUno.x && (this.x)<(autoUno.x+anchoAuto))){
			vidas--;
			dolares=dolares-50;	
			this.sortear();
			perderDineroAudio.play();

		}
		//evaluar balas
        for (i in disparos) {
            if ( 
                disparos[i].x >= this.x  &&
                disparos[i].x <= (this.x + 80)  &&
                disparos[i].y <= (this.y + 50)  &&
                disparos[i].y >= this.y
            ) {
                disparos.splice(i, 1);
            	dolares+=20;
            	this.sortear();
				dineroAudio.play();	

            }
        }

	}
	this.sortear=function(){
		this.x=Math.floor(
				Math.random()*(700-40+1)
			)+40;
		this.y=Math.floor(
				Math.random()*((-70)-(-200)+1)
			)+(-200);
	}
}
function Auto(x,y){
	this.x=x;
	this.y=y;

	this.dibujar=function(img){
		ctx.drawImage(img,this.x,this.y,anchoAuto,altoAuto);
	}	
	this.derecha=function(){
		this.x+=20;
	}
	this.izquierda=function(){
		this.x-=20;
	}
	this.arriba=function(){
		if(this.y>250){
			this.y-=30;
			this.x+=10;
		}
		
	}
	this.abajo=function(){
		if(this.y<350){
			this.y+=30;
			this.x+=10;
		}
	}
}
function borrar(){
	canvas.width=800;
	canvas.height=600;
}
function dibujarDisparos() {
    for(i in disparos) {
        ctx.drawImage(imgDisparo,disparos[i].x,disparos[i].y);
    }
}
function moverDisparos() {
    for(i in disparos ) {
    	disparos[i].y -=8;
    }
}

document.addEventListener('keydown',function(e){
	if(e.keyCode==32){
		disparos.push({
            x: autoUno.x + 20,
            y: autoUno.y - 20 
        });
	}
	if(e.keyCode==37){
		autoUno.izquierda();
	}
	if(e.keyCode==39){
		autoUno.derecha();
	}
});


document.addEventListener("click",function(e){
 	if(vidas<=0 || dolares<=-10){
 		if(e.x>600&&e.x<700&&e.y>300&&e.y<380){
 			vidas=3;
 			dolares=0;
			autoUno.x= posXAuto;
			autoUno.y= posYAuto;
			iniciar_juego();				
 		}
 	}else if(inicio==false){
 		juego();
 	}	
 });

 document.addEventListener('mousemove',function(e){
	if(vidas<=0 || dolares<=-10){
		if(e.x>500&&e.x<890&&e.y>300&&e.y<380){
				canvas.style.cursor="pointer";
				colorBoton="#ff5733";
		}else{
			canvas.style.cursor="";
			colorBoton="#000";

		}
		
		}
	}
	
);